// api/alerts.js
// Serverless function: fetches from oref.org.il server-side (no CORS issues)
// Caches for 30 seconds to avoid hammering the source

let cache = { data: null, ts: 0 };
const CACHE_TTL = 30 * 1000; // 30 seconds

const OREF_HISTORY = 'https://www.oref.org.il/WarningMessages/History/AlertsHistory.json';
const OREF_REALTIME = 'https://www.oref.org.il/WarningMessages/alert/alerts.json';

export default async function handler(req, res) {
  // CORS headers so the browser can call this freely
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET');
  res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=60');

  const type = req.query.type || 'history';

  try {
    // Return cached data if fresh
    const now = Date.now();
    if (cache.data && (now - cache.ts) < CACHE_TTL) {
      return res.status(200).json({ source: 'cache', ...cache.data });
    }

    // Fetch history (last 24h alerts)
    const historyRes = await fetch(OREF_HISTORY, {
      headers: {
        'Referer': 'https://www.oref.org.il/',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (compatible; ThreatMonitor/1.0)',
      },
      signal: AbortSignal.timeout(8000),
    });

    let history = [];
    if (historyRes.ok) {
      const text = await historyRes.text();
      try { history = JSON.parse(text); } catch {}
    }

    // Fetch realtime (active right now)
    let realtime = null;
    try {
      const rtRes = await fetch(OREF_REALTIME, {
        headers: {
          'Referer': 'https://www.oref.org.il/',
          'X-Requested-With': 'XMLHttpRequest',
        },
        signal: AbortSignal.timeout(4000),
      });
      const rtText = await rtRes.text();
      if (rtText && rtText.trim().length > 2) {
        realtime = JSON.parse(rtText);
      }
    } catch {}

    const payload = {
      history: Array.isArray(history) ? history : [],
      realtime,
      fetchedAt: new Date().toISOString(),
    };

    // Cache it
    cache = { data: payload, ts: now };

    return res.status(200).json({ source: 'live', ...payload });

  } catch (err) {
    console.error('oref fetch error:', err.message);

    // Return cached stale data if available
    if (cache.data) {
      return res.status(200).json({ source: 'stale', ...cache.data });
    }

    return res.status(502).json({ error: 'Failed to fetch from oref.org.il', detail: err.message });
  }
}
