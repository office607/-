# 🚨 מוניטור איום — ישראל

מערכת ניטור אזעקות בזמן אמת על בסיס נתוני פיקוד העורף.

---

## 🚀 העלאה ל-Vercel (חינמי, 5 דקות)

### שלב 1 — צור חשבון Vercel
היכנס לאתר: https://vercel.com  
לחץ **Sign Up** → הירשם עם GitHub (מומלץ) או אימייל.

---

### שלב 2 — העלה את הקבצים

**אפשרות א׳ — דרך הדפדפן (הכי קל):**

1. היכנס ל-https://vercel.com/new
2. בחר **"Browse"** / **"Upload folder"**
3. גרור את תיקיית `oref-monitor` כולה
4. לחץ **Deploy**
5. ✅ תוך 30 שניות תקבל קישור כמו `https://oref-monitor-xxxx.vercel.app`

**אפשרות ב׳ — דרך GitHub:**

1. צור repository חדש ב-GitHub
2. העלה את כל הקבצים לתוכו
3. ב-Vercel לחץ **"Import Git Repository"**
4. בחר את ה-repository
5. לחץ **Deploy**
6. כל push עתידי יעדכן את הסייט אוטומטית ✨

---

## 📁 מבנה הפרויקט

```
oref-monitor/
├── vercel.json          ← הגדרות ניתוב
├── package.json         ← מידע פרויקט
├── api/
│   └── alerts.js        ← Backend: מושך נתונים מ-oref.org.il
└── public/
    └── index.html       ← Frontend: ממשק המשתמש
```

---

## ⚙️ איך זה עובד

```
המשתמש (דפדפן)
      │
      ▼
  /api/alerts          ← Vercel Serverless Function
      │
      ▼
  oref.org.il          ← נתוני אזעקות אמיתיים
```

ה-Backend רץ בצד השרת של Vercel לכן:
- ✅ אין בעיות CORS
- ✅ יש caching של 30 שניות (לא מעמיס על oref)
- ✅ עובד לכל אחד שפותח את הקישור

---

## ⚠️ הבהרה

המערכת מציגה נתונים סטטיסטיים בלבד.
במקרה של אזעקה — פעל לפי פיקוד העורף בלבד.
מספר חירום: **104**
